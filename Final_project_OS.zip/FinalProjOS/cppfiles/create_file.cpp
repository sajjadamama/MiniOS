void create_file() {
    char filename[100];
    printf("\n📄 Enter file name to create: ");
    scanf("%s", filename);
    FILE *fp = fopen(filename, "w");
    if (fp) {
        printf("File '%s' created successfully.\n", filename);
        fclose(fp);
    } else {
        perror("Error creating file");
    }
}
