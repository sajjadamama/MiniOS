void read_file() {
    char filename[100];
    printf("\n📖 Enter file name to read: ");
    scanf("%s", filename);
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Unable to open file");
        return;
    }
    char ch;
    while ((ch = fgetc(fp)) != EOF) putchar(ch);
    fclose(fp);
}
