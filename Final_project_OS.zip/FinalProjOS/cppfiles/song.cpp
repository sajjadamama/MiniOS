void play_song() {
    char filename[100];
    printf("\n🎵 Enter the name of the song file (e.g., havana.mp3): ");
    scanf("%s", filename);
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "mpg123 /home/ns3/Music/%s", filename);
    system(cmd);
}

