void copy_move_file() {
    char src[100], dest[100];
    printf("\n📄 Enter source file name: ");
    scanf("%s", src);
    printf("Enter destination file name: ");
    scanf("%s", dest);

    FILE *fsrc = fopen(src, "r");
    FILE *fdest = fopen(dest, "w");
    if (!fsrc || !fdest) {
        perror("Error");
        return;
    }
    char ch;
    while ((ch = fgetc(fsrc)) != EOF) fputc(ch, fdest);
    fclose(fsrc);
    fclose(fdest);
    printf("File copied to %s.\n", dest);
}
