void create_directory() {
    char dirname[100];
    printf("\n📁 Enter directory name: ");
    scanf("%s", dirname);
    if (mkdir(dirname, 0777) == 0)
        printf("Directory '%s' created successfully.\n", dirname);
    else
        perror("Error creating directory");
}

