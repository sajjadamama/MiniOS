void list_files() {
    DIR *d;
    struct dirent *dir;
    d = opendir(".");
    if (d) {
        printf("\n📂 Listing files in current directory:\n");
        while ((dir = readdir(d)) != NULL) {
            if (dir->d_type == DT_REG)
                printf("- %s\n", dir->d_name);
        }
        closedir(d);
    }
}
