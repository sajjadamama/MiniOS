void delete_file() {
    char filename[100];
    printf("\n❌ Enter file name to delete: ");
    scanf("%s", filename);
    if (remove(filename) == 0)
        printf("File '%s' deleted successfully.\n", filename);
    else
        perror("Error deleting file");
}
