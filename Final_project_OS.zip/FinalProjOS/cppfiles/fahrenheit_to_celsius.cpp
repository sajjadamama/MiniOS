void fahrenheit_to_celsius() {
    float f;
    printf("\n🌡️ Enter temperature in Fahrenheit: ");
    scanf("%f", &f);
    float c = (f - 32) * 5 / 9;
    printf("Temperature in Celsius: %.2f\n", c);
}
