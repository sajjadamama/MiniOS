void show_kernel_specs() {
    printf("\n🧠 Kernel Mode Specifications:\n");
    printf("🧬 CPU Cores:\n");
    system("nproc");

    printf("💾 RAM Info (in GB):\n");
    system("free -g | awk '/Mem:/ {print $2 \" GB RAM\"}'");

    printf("🖴 HDD Info:\n");
    system("lsblk -o NAME,SIZE,TYPE | grep disk");
}
